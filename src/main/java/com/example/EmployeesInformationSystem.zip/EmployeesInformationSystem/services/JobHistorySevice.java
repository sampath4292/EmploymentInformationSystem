package com.example.EmployeesInformationSystem.services;

import java.sql.Date;
import java.util.List;


import com.example.EmployeesInformationSystem.entity.JobHistory;


public interface JobHistorySevice {

    List<JobHistory> EmployeeJobHistory(Integer a);
    int SaveEmpHistory(Integer a, Integer b,Date c,Date d);
}
